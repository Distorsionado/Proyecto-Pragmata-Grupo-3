import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Fabian: Thiago quien es mas lindo Ortiz o Facundo? ");
        System.out.println("Thiago: ");
        System.out.println("█      ███   ████    ████   ███   ████ █   █ \n" +
                "█     █   █ █        █   █ █   █ █     █   █ \n" +
                "█     █   █  ███     █   █ █   █  ███  █████ \n" +
                "█     █   █     █    █   █ █   █     █ █   █ \n" +
                "█████  ███  ████     ████   ███  ████  █   █ ");
        tabla tablero  = new tabla();
        Jugador jugador  = new Jugador();
        boolean jugando  = true;

        System.out.println(" ");
        tablero.mostrar(jugador.getFila(), jugador.getCol());

        while (jugando) {
            System.out.println("Posicion actual: [" + jugador.getFila() + "," + jugador.getCol() + "]  Puntaje: " + jugador.getPuntaje());

            boolean seMov = false;

            System.out.print("W=arriba  S=abajo  A=izquierda  D=derecha: ");
            String tecla = scanner.nextLine().trim().toLowerCase();

            String dir = "";
            if (tecla.equals("w"))      dir = "arriba";
            else if (tecla.equals("s")) dir = "abajo";
            else if (tecla.equals("a")) dir = "izquierda";
            else if (tecla.equals("d")) dir = "derecha";
            else System.out.println("Tecla invalida.");

            if (!dir.isEmpty()) {
                seMov = jugador.mover(dir);
            }

            if (seMov) {
                Celda celdaActual = tablero.getCelda(jugador.getFila(), jugador.getCol());

                if (celdaActual.getTipo().equals("objetivo")) {
                    jugador.setPuntaje(jugador.getPuntaje() + 100);
                    tablero.mostrar(jugador.getFila(), jugador.getCol());
                    System.out.println("LO LOGRASTE SOS LA CABRA");
                    System.out.println("Puntaje final: " + jugador.getPuntaje());
                    jugando = false;

                } else if (celdaActual.getTipo().equals("potenciador") && !celdaActual.isVisitada()) {
                    jugador.setPuntaje(jugador.getPuntaje() * 2);
                    celdaActual.setVisitada(true);
                    System.out.println("Potenciador de aura Puntaje duplicado -> " + jugador.getPuntaje());
                    tablero.mostrar(jugador.getFila(), jugador.getCol());

                } else if (celdaActual.getTipo().equals("modificador") && !celdaActual.isVisitada()) {
                    jugador.setPuntaje(jugador.getPuntaje() + 50);
                    celdaActual.setVisitada(true);
                    System.out.println("Modificador de belleza +50 puntos  " + jugador.getPuntaje());
                    tablero.mostrar(jugador.getFila(), jugador.getCol());

                } else {
                    tablero.mostrar(jugador.getFila(), jugador.getCol());
                }
            }
        }

        scanner.close();
    }
}
