public class Celda {


    private String tipo;
    private boolean visitada;

    public Celda(String tipo) {
        this.tipo = tipo;
        this.visitada = false;
    }
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isVisitada() {
        return visitada;
    }

    public void setVisitada(boolean visitada) {
        this.visitada = visitada;
    }

    // Te amo profe
    public String toString() {
        if (tipo.equals("inicio"))       return "[ I]";
        if (tipo.equals("objetivo"))     return "[ X ]";
        if (tipo.equals("potenciador"))  return "[ P ]";
        if (tipo.equals("modificador"))  return "[ M ]";
        return "[   ]";
    }
}

