public class Jugador {

    private int fila;
    private int col;
    private int puntaje;

    public Jugador() {
        this.fila = 0;
        this.col = 0;
        this.puntaje = 0;
    }
    public boolean mover(String direccion) {
        int nuevaFila = fila;
        int nuevaCol  = col;

        if (direccion.equals("arriba"))         nuevaFila--;
        else if (direccion.equals("abajo"))     nuevaFila++;
        else if (direccion.equals("izquierda")) nuevaCol--;
        else if (direccion.equals("derecha"))   nuevaCol++;
        else {
            System.out.println("Direccion no reconocida");
            return false;
        }
        if (nuevaFila < 0 || nuevaFila >= 4 || nuevaCol < 0 || nuevaCol >= 4) {
            System.out.println("No podes moverte en esa direcion, te salis del tablero!");
            return false;
        }
        fila = nuevaFila;
        col  = nuevaCol;
        return true;
    }
    public int getFila() { return fila; }
    public int getCol()  { return col;  }

    public int getPuntaje() { return puntaje; }
    public void setPuntaje(int puntaje) { this.puntaje = puntaje; }
}
