

public class tabla {

    private Celda[][] grilla;
    private int tamanio = 4;

    public tabla() {
        this.grilla = new Celda[tamanio][tamanio];
        generarTablero();
    }

    private void generarTablero() {
        for (int i = 0; i < tamanio; i++) {
            for (int j = 0; j < tamanio; j++) {
                grilla[i][j] = new Celda("vacia");
            }
        }

        // Celdas profea aca estan las celdas profeeeeeeeeeeee miralaaaasss xd
        grilla[0][0].setTipo("inicio");
        grilla[1][2].setTipo("objetivo");
        grilla[2][0].setTipo("potenciador");
        grilla[3][1].setTipo("potenciador");
        grilla[2][3].setTipo("modificador");
        grilla[3][3].setTipo("modificador");
    }

    public void mostrar(int jugadorFila, int jugadorCol) {
        System.out.println();
        System.out.print("     ");
        for (int c = 0; c < tamanio; c++) {
            System.out.print("  " + c + "   ");
        }
        System.out.println();

        for (int i = 0; i < tamanio; i++) {
            System.out.print("  " + i + "  ");
            for (int j = 0; j < tamanio; j++) {
                if (i == jugadorFila && j == jugadorCol) {
                    System.out.print("[ T ] ");
                } else {
                    System.out.print(grilla[i][j].toString() + " ");
                }
            }
            System.out.println();
        }

        System.out.println();
        System.out.println("Info: [T] jugador  [I] inicio  [x] objetivo  [P] potenciador  [M] modificador");
        System.out.println();
    }

    public Celda getCelda(int fila, int col) {
        return grilla[fila][col];
    }
}